#Udacity Project 2 "Landing Page"

This is a single page webpage utilizing Javascript for dynamic additions and smooth scroll effect. In-addition Active state navigation on scroll

## Installation

No installation required

```bash
N/A
```

## Usage

```
N/A
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
N/A